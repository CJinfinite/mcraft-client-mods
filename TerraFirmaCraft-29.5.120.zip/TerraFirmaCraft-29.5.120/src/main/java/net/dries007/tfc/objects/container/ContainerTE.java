/*
 * Work under Copyright. Licensed under the EUPL.
 * See the project README.md and LICENSE.txt for more information.
 */

package net.dries007.tfc.objects.container;

import java.util.stream.IntStream;
import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import net.dries007.tfc.objects.te.ITileFields;
import net.dries007.tfc.objects.te.TEInventory;

/**
 * This is the mother of all Container-with-a-Tile-Entity implementations
 *
 * @param <T> The Tile Entity class
 */
@ParametersAreNonnullByDefault
public abstract class ContainerTE<T extends TEInventory> extends ContainerSimple implements ICapabilityUpdateContainer
{
    protected final T tile;
    protected final EntityPlayer player;

    private final boolean shouldSyncFields;
    private final int yOffset; // The number of pixels higher than normal (If the gui is larger than normal, see Anvil)

    private int[] cachedFields;
    private IContainerListener capabilityListener; // Set via ICapabilityUpdateContainer, used to sync cap only updates

    protected ContainerTE(InventoryPlayer playerInv, T tile)
    {
        this(playerInv, tile, 0);
    }

    protected ContainerTE(InventoryPlayer playerInv, T tile, int yOffset)
    {
        this.tile = tile;
        this.player = playerInv.player;
        this.shouldSyncFields = tile instanceof ITileFields;
        this.yOffset = yOffset;

        addContainerSlots();
        addPlayerInventorySlots(playerInv);
    }

    @Override
    public void detectAndSendChanges()
    {
        if (shouldSyncFields)
        {
            detectAndSendFieldChanges();
        }
        for (int i = 0; i < inventorySlots.size(); ++i)
        {
            ItemStack newStack = inventorySlots.get(i).getStack();
            ItemStack cachedStack = inventoryItemStacks.get(i);

            if (!ItemStack.areItemStacksEqual(cachedStack, newStack))
            {
                // Duplicated from Container#detectAndSendChanges
                boolean clientStackChanged = !ItemStack.areItemStacksEqualUsingNBTShareTag(cachedStack, newStack);
                cachedStack = newStack.isEmpty() ? ItemStack.EMPTY : newStack.copy();
                this.inventoryItemStacks.set(i, cachedStack);

                if (clientStackChanged)
                {
                    for (IContainerListener listener : this.listeners)
                    {
                        listener.sendSlotContents(this, i, cachedStack);
                    }
                }
                else if (capabilityListener != null)
                {
                    // There's a capability difference ONLY that needs to be synced, so we use our own handler here, as to not conflict with vanilla's sync, because this won't overwrite the client side item stack
                    // The listener will check if the item actually needs a sync based on capabilities we know we need to sync
                    capabilityListener.sendSlotContents(this, i, cachedStack);
                }
            }
        }
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void updateProgressBar(int id, int data)
    {
        if (shouldSyncFields)
        {
            ((ITileFields) tile).setField(id, data);
        }
    }

    @Override
    @Nonnull
    public ItemStack transferStackInSlot(EntityPlayer player, int index)
    {
        // Slot that was clicked
        Slot slot = inventorySlots.get(index);
        if (slot != null && slot.getHasStack())
        {
            ItemStack stack = slot.getStack();
            ItemStack stackCopy = stack.copy();

            // Transfer out of the container
            int containerSlots = inventorySlots.size() - player.inventory.mainInventory.size();
            if (index < containerSlots)
            {
                if (transferStackOutOfContainer(stack, containerSlots))
                {
                    return ItemStack.EMPTY;
                }
            }
            // Transfer into the container
            else if (transferStackIntoContainer(stack, containerSlots))
            {
                return ItemStack.EMPTY;
            }

            if (stack.getCount() == 0)
            {
                slot.putStack(ItemStack.EMPTY);
            }
            else
            {
                slot.onSlotChanged();
            }
            if (stack.getCount() == stackCopy.getCount())
            {
                return ItemStack.EMPTY;
            }
            slot.onTake(player, stack);
            return stackCopy;
        }
        return ItemStack.EMPTY;
    }

    @Override
    public boolean canInteractWith(EntityPlayer playerIn)
    {
        return tile.canInteractWith(player);
    }

    @Override
    protected void addPlayerInventorySlots(InventoryPlayer playerInv)
    {
        super.addPlayerInventorySlots(playerInv, yOffset);
    }

    protected abstract void addContainerSlots();

    protected void detectAndSendFieldChanges()
    {
        ITileFields tileFields = (ITileFields) tile;
        boolean allFieldsHaveChanged = false;
        boolean[] fieldHasChanged = new boolean[tileFields.getFieldCount()];

        if (cachedFields == null)
        {
            cachedFields = new int[tileFields.getFieldCount()];
            allFieldsHaveChanged = true;
        }

        for (int i = 0; i < cachedFields.length; ++i)
        {
            if (allFieldsHaveChanged || cachedFields[i] != tileFields.getField(i))
            {
                cachedFields[i] = tileFields.getField(i);
                fieldHasChanged[i] = true;
            }
        }

        // go through the list of listeners (players using this container) and update them if necessary
        for (IContainerListener listener : this.listeners)
        {
            for (int fieldID = 0; fieldID < tileFields.getFieldCount(); ++fieldID)
            {
                if (fieldHasChanged[fieldID])
                {
                    // Note that although sendWindowProperty takes 2 ints on a server these are truncated to shorts
                    listener.sendWindowProperty(this, fieldID, cachedFields[fieldID]);
                }
            }
        }
    }

    @Override
    public void setCapabilityListener(IContainerListener capabilityListener)
    {
        this.capabilityListener = capabilityListener;
    }

    protected boolean transferStackOutOfContainer(ItemStack stack, int containerSlots)
    {
        return !mergeItemStack(stack, containerSlots, inventorySlots.size(), true);
    }

    protected boolean transferStackIntoContainer(ItemStack stack, int containerSlots)
    {
        return !mergeItemStack(stack, 0, containerSlots, false);
    }

    @Deprecated
    protected int[] getSlotShiftOrder(int containerSlots)
    {
        return IntStream.range(0, containerSlots).toArray();
    }
}
